import React,{useState, useEffect} from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Axios from 'axios'
import { UseAppContext } from '../../../Contexts/app-context'
import Alert from '@mui/material/Alert';
import "./SignUp.css"
import { Button, Typography, TextField } from '@mui/material';
import API from '../../../resourses/api';

const SignUp =()=>{ 
    const {loggedIn, loading, setCurrentUser, currentUser} = UseAppContext()
    const [error, setError] = useState({status: false, msg :''})
    const [formValues, setFormValues] = useState({
        firstname : "",
        lastname : "",
        email : '',
        password1 : "",
        password2 : "",
    })
    const navigate = useNavigate()

   
   
  const [open, setOpen] = React.useState(false);
  
  const handleError = (status, message) => {
    setOpen(true);
    setError({status : status, msg : message})
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  const setSignupValues =(data)=>{
    setCurrentUser(data) 
  }

    const setValues =(e)=>{
        let name = e.target.name
        let value = e.target.value

        setFormValues(prev => {
            return{...prev, [name] : value}
        })
    }



    const signUp = async(e)=>{
      
      e.preventDefault()
      const { firstname, lastname, email, password1, password2} = formValues
     
        if(!firstname){
          setError({status : true, msg : "Please enter Your first name"})
          setTimeout(()=>{
             return setError({status : false, msg :''})
          }, 4000)
       }else if(!lastname){
          setError({status : true, msg : "Please enter Your last name"})
          setTimeout(()=>{
              setError({status : false, msg :''})
          }, 4000)
      }else if(!email){
          setError({status : true, msg : "Please enter Your E-mail"})
          setTimeout(()=>{
              setError({status : false, msg :''})
          }, 4000)
      }else if(password2.length == 0 || password1.length == 0){
          setError({status : true, msg : "Please enter and comfirm your password"})
          setTimeout(()=>{
              setError({status : false, msg :''})
          }, 4000)
      } else if(password2.length < 8 || password1.length < 8){
        setError({status : true, msg :'Password must be 8 characters or more'})
        setTimeout(()=>{
            setError({status : false, msg :''})
        }, 4000)
    }else{
            if(password2 !== password1){
              setError({status : true, msg :'Password mismatch'})
              setTimeout(()=>{
                  setError({status : false, msg :''})
              }, 4000)
           }else{
            const options = {
                url: `${API}/auth/create-user`,
                method : "POST",
                headers : {
                    "Accept" : "application/json",
                    "Content-Type" : "application/json"
                },
                data:{
                    firstname : firstname, 
                    lastname : lastname,
                    email : email,
                    password : password1
                }
            }

            setTimeout(()=>{
              setError({status : true, msg :"Please check your network connection"})
            },10000)
            setTimeout(()=>{
              setError({status : false, msg :""})
            },16000)
            const result = await Axios(options)
            const {response, userValue} = result.data
            
            if(response === 'Success'){
                setSignupValues(userValue)
                return window.location.href = `/sign-in`
                
            }else if(response === 'Fail'){
                const {message} = result.data
                handleError(true, message)
                setTimeout(()=>{
                    setError({status : false, msg :''})
                }, 4000)
            }

          }
        }
    }

    useEffect(() => {
        window.scrollTo(0, 0)
    }, [])


    return (
    <div className='signup' >
    <div className='signup-heading' >
      <h1>
        Smart Pacific
      </h1>
    </div>
    <div className='signup-form' >
    {
          error.status && <div className='sign-up-alert' >
          <Alert severity="error">{error.msg}</Alert>
        </div>
      }
      <div className='sign-up-form'>
        <h6 className='sign-up-title'>
          Sign Up
        </h6>
        <TextField
          className='signup-input'
          value={formValues.firstname}
          onChange={setValues}
          type='text'
          name='firstname'
          label='Firstname'
          margin="normal"
          required
        />
        <TextField
          className='signup-input'
          value={formValues.lastname}
          onChange={setValues}
          type='text'
          name='lastname'
          label='Lastname'
          margin="normal"
          required
        />
        <TextField
          className='signup-input'
          value={formValues.email}
          onChange={setValues}
          type='email'
          name='email'
          label='E-Mail'
          margin="normal"
          required
        />
        <TextField
          className='signup-input'
          value={formValues.password1}
          onChange={setValues}
          type='password'
          name='password1'
          label='Password'
          margin="normal"
          required
        />
        <TextField
          className='signup-input'
          value={formValues.password2}
          onChange={setValues}
          type='password'
          name='password2'
          label='Comfirm Password'
          margin="normal"
          required
        />
        <div className='auth-btns'>
          <Button  
          sx={{
            backgroundColor: 'var(--background-color-9)',
            color: 'var(--color3)',
            border: '1px solid var(--background-color-9)',
            '&:hover': {
              backgroundColor: 'var(--background-color-8)',
              color: 'var(--color3)',
              border: '1px solid var(--background-color-8)'
            },
          }}
          onClick={signUp} variant="contained">
            Sign up
          </Button>
        </div>
        <div className='auth-alt-text'>
          Already have an account? <br />
          <Link to='/sign-in' className='auth-signup-btn'>
            Sign in
          </Link>
        </div>
      </div>
    </div>
  </div>
)}
 
export default SignUp