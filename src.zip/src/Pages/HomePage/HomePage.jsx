import React from 'react'
import "./HomePage.css"
import { useRef } from 'react'
import { Navbar, Sidebar, Footer, Backdrop } from '../../Components'
import { UseAppContext } from '../../Contexts/app-context'
import { Navigate } from 'react-router-dom'
import HeroSection from './HomePageComponents/HeroSection'
import FeaturedSection from './HomePageComponents/FeaturedSection'
import NewArrivalsSection from './HomePageComponents/NewArrivalsSection'
import DealsSection from './HomePageComponents/DealsSection'

const HomePage = () => {
  const {loggedIn, featured} = UseAppContext()

  
  return (
    <>
    <Navbar />
    <Sidebar />
    <Backdrop />
    <HeroSection />
    <FeaturedSection />
    <NewArrivalsSection />
    <DealsSection />
    <Footer />
    </>
  )
}

export default HomePage