import React from 'react'
import { UseAppContext } from '../../../Contexts/app-context'
import { Link } from 'react-router-dom';

const NewArrivalsSection = () => {
    const {products} = UseAppContext()

    const productsCopy = [...products];
    const reversedProducts = productsCopy.reverse();
    const latestProducts = reversedProducts.slice(0, 5);

    return (
        <div className='new-arrivals'>
        <h3 className='new-arrivals-title'>New Arrivals</h3>
        <div className='new-arrivals-products'>
            {
                latestProducts.map(product =>{
                    const {_id, productName, productImages} = product
                    return <Link to={`/product/${_id}`} key={_id} className='new-arrivals-product'>
                        <div className='new-arrivals-image-container'>
                        <img src={product.productImages[0]} alt={`img_${product._id}`} className='new-arrivals-image' />
                        </div>
                        <div className='new-arrivals-product-name'>
                            {productName}
                        </div>
                    </Link>
                })
            }
            </div>
        </div>
    )
}

export default NewArrivalsSection