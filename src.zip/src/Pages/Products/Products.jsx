import React, { useEffect } from 'react'
import { Navbar, Sidebar, Footer, Backdrop } from '../../Components'
import "./products.css"
import { UseAppContext } from '../../Contexts/app-context'
import ProductList from '../../Components/ProductList/ProductList'
import { Grid } from '@mui/material'
import { FaTableCells } from "react-icons/fa6";
import { FaTableList } from "react-icons/fa6";
import { uniqueValues, capitalizeFirstLetter } from '../../resourses/functions'

const Products = () => {
  const {products, filteredProducts, view, setView, sort, changeSort,
    filters, setFilterValues, clearFilterValues} = UseAppContext()
    const {search_text} = filters
    const {lowest_price, highest_price, price, shipping} = filters
    const uniqueCategory = uniqueValues(products, "productCategory")
    const uniqueColors = uniqueValues(products, "colors")
    const uniqueCompanies = uniqueValues(products, "manufacturer")
    

    useEffect(() => {
      window.scrollTo(0, 0)
    }, [])

  return (<>
    <Navbar />
      <Sidebar />
      <Backdrop />
      <Grid className='products'>
      <h3 className='title'>Products</h3>
      <Grid container className='products-inner'>
      <Grid item xs={12} sm={2} className='filters'>
        <h4>Filters</h4>
        <form onSubmit={(e)=>e.preventDefault()}>
          <input type="text" name="search_text" value={search_text}
          className="search"
          placeholder='Search...'
          onChange={setFilterValues}/>
        </form>
        <br />
        <h5>Category</h5>
        {
          uniqueCategory.map((category, index)=>{
            return <><button key={index}
            className={capitalizeFirstLetter(filters.category) == capitalizeFirstLetter(category) ? "category-button-active" : "category-button"}
            name="category"
            onClick={setFilterValues}
            >{capitalizeFirstLetter(category)}</button><br/></>
          })
        }        
        <br />
        <h5>Company</h5>
        <select name="company" onChange={setFilterValues}
        value={filters.company}>
        {
          uniqueCompanies.map((company, index) =>{
            return<option key={index} >
              {capitalizeFirstLetter(company)}</option>
          })
        }
        </select>
        <br />
        <br />
        <h5>Color</h5>
        {
          uniqueColors.map((color, index)=>{
            if(color === "All"){
              return <button className={filters.color == color ? "color-button-active" : "color-button"} name="color"
              key={index} onClick={setFilterValues} data-color="All">All</button>
            }
            return<button key={index}
            style={{backgroundColor: color}}
            className={filters.color == color ? "color-button-active" : "color-button"}
            onClick={setFilterValues}
            name="color"
            data-color={color}
            ></button>
          })
        }
        <br />
        <br />
        <h5>Price</h5>
        <input type="range" name="price"
         value={price} min={lowest_price} max={highest_price}
        onChange={setFilterValues} />
        <h5 className='shipping'>Shipping: 
          <input type='checkbox' name="shipping" checked={shipping}
          onChange={setFilterValues} />
        </h5>
        <br />
        <button onClick={clearFilterValues}
        className='clear-filters'>Clear filters</button>
      </Grid>
      <Grid item xs={12} sm={10} className='productsList'>
        <div className='product-list-top-right'>
        <div className='view-buttons'>
        <FaTableCells onClick={() => setView("grid")} 
        className={view == "grid" ? "view-button-active":"view-button"}/>
        <FaTableList onClick={() => setView("list")} 
        className={view == "list" ? "view-button-active":"view-button"}/>
        </div>
        <form>
        <label htmlFor="sort">Sort By:</label>
        <select name="sort" id="sort" className='sort ' value={sort} 
        onChange={(e)=>changeSort(e.target.value)}>
          <option value="price-lowest">Price (Lowest to Highest)</option>
          <option value="price-highest">Price (Highest to Lowest)</option>
          <option value="name-a">Name (A-Z)</option>
          <option value="name-z">Name (Z-A)</option>
        </select>
      </form>
        </div>
        <br /> 
        <br /> 
        <ProductList products={filteredProducts} />
      </Grid>
    </Grid>
    </Grid>
      <Footer />
      </>
  )
}

export default Products