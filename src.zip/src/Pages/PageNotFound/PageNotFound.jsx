import React from 'react'
import "./PageNotFound.css"
import { Navbar, Sidebar, Backdrop, Footer } from '../../Components'

const PageNotFound = () => {
  return (
    <div className='main'>
    <Navbar />
    <Sidebar />
    <Backdrop />
    <div className='page-not-found'>
    <div className='not-found-code'>404</div>
    Page Not Found
    </div>
    <Footer />
    </div>

  )
}

export default PageNotFound