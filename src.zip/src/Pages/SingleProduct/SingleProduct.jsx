import React, { useEffect, useState } from 'react'
import { Navbar, Sidebar, Footer } from '../../Components'
import { UseAppContext } from '../../Contexts/app-context'
import { useParams } from 'react-router-dom'
import ImageSlider from '../../Components/ImageSlider/ImageSlider'
import "./SingleProduct.css"
import {formattedPrice} from '../../resourses/functions'
import AddToCart from '../../Components/AddToCart/AddToCart'

const SingleProduct = () => {
  const {product, fetchSingleProduct} = UseAppContext()
  const [selectedColor, setSelectedColor] = useState("")
  const {colors, description, freeShipping, inventory, manufacturer, price, 
   productCategory, productImages, productName, _id} = product
  const {id} = useParams()

  useEffect(()=>{
    fetchSingleProduct(id)
  },[])
  
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

 
  return (
    <>
      <Navbar />
      <Sidebar />
      {productName ? <div className='single-product row' >
        <div className='col-12 col-sm-6'>
            <div className="images-section">
                <ImageSlider images={productImages} />
            </div>
        </div>
        <div className='col-12 col-sm-6'>
          <div className='product-details'>
            <h3 className='name'>{productName}</h3>
            <div className='info price'>Price: {formattedPrice(price)}</div>
            <div className='info colors'>Colors:<div className='colors'>{colors.map(color =>{
             
              return <div 
              style={{backgroundColor:`${color}`}} 
              onClick={()=>setSelectedColor(color)}
              className='color'>
              </div>
            })}</div></div>
            <div className='info'>Product description: {description}</div>
            <div className='info'>Available:{inventory}</div>
            <div className='info'>Brand: {manufacturer}</div>
            <div className='info'>Shipping: {freeShipping ? "Yes" : "No"}</div>
            <div className='info'>Category: {productCategory}</div>
            {inventory > 0 && <AddToCart
            product = {product}
            selectedColor = {selectedColor}
          />}
          </div>
        </div>
      </div> : <div>Loading...</div>}
      <Footer />
    </>
  )
}

export default SingleProduct