import React, { useEffect } from 'react'
import { Navbar, Sidebar, Footer, Backdrop} from '../../Components'
import { UseAppContext } from '../../Contexts/app-context'
import "./Cart.css"
import { formattedPrice } from '../../resourses/functions'
import { Link } from 'react-router-dom'
import {loadStripe} from '@stripe/stripe-js';
import Axios from "axios"
import API from '../../resourses/api'
import { FaArrowRightToBracket } from "react-icons/fa6"

const Cart = () => {
  const {loggedIn, currentUserParsed, cart, decreaseCartItem,
  increaseCartItem, deleteCartItem, clearCart} = UseAppContext()
  const urlParams = new URLSearchParams(window.location.search);
  const {_id} = currentUserParsed
  let total = 0

  const filteredCart = cart.filter(item => item.userId === currentUserParsed._id);

  const payTotal = async () => {
    try {
    
      const stripe = await loadStripe("pk_test_gxfekKu4IwU4ZIVoJ0cG5pb200MfcjbMqA");

    
      const body = {
        userId: _id,
        products: filteredCart
      };

    
      const headers = {
        "Content-Type": "application/json"
      };

    
      const response = await Axios.post(`${API}/payment/checkout`, body, {
        headers: headers
      });

    
      const session = response.data;

    
      const result = await stripe.redirectToCheckout({
        sessionId: session.id
      });

    
      if (result.error) {
        console.error(result.error);
      }
    } catch (error) {
      console.error(error.message);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  
  if (urlParams.has('clearCart')) {
    clearCart();
  }

  return (
    <div>
      
      <Navbar />
      <Sidebar />
      <Backdrop />
      {loggedIn == "true" ?
      <div className={cart.length > 0 ? "cart" : 'empty-cart-page'}>
        <h3>Cart <span className='cart-count-heading'>{filteredCart.length} {filteredCart.length > 1 ? "items" : "item"}</span></h3>
        {
          
          filteredCart.length > 0 ? 
          <div >
          {
          filteredCart.map(cartItem=>{
            const {id, productName, selectedColor, quantity, inventory, image, price} = cartItem
            const strippedId = id.split("_")[0]
            total += (quantity * price)
            return <div className='cart-item' key={id}>
              <Link to={`/product/${strippedId}`} className='link-to-product'>
                <img src={image} alt={`img_${strippedId}`} className='cart-image'/>
              </Link>
              <h5 className='cart-product-name'>{productName}</h5><button className='delete-cart-item' onClick={()=>deleteCartItem(id)}>Delete</button>
              <div className='cart-product-color'>Color: <div style={{background: `${selectedColor}`}} 
              className='cart-color'></div>{selectedColor}</div>
              <div className='cart-product-quntity'>Quantity: 
              <div className='cart-quntity-items'>
                <button className='cart-quntity-button' onClick={()=>decreaseCartItem (cartItem)}>-</button>
                <div className='cart-quntity'>{quantity}</div>
                <button className='cart-quntity-button' onClick={()=>increaseCartItem (cartItem)}>+</button>
              </div>
              </div>
              <div className='cart-product-inventory'>Available: {inventory}</div>
              <div className='cart-product-price'>Unit price: <span className='cart-product-price-2'>{formattedPrice(price)}</span></div>
              <div className='cart-product-subtotal'>Sub total: <span className='cart-product-subtotal-2'>{formattedPrice(price * quantity)}</span></div>
            </div>
          })
        }

          <div className='cart-total'>Total: {formattedPrice(total)}</div>
          
          <div className='cart-option-buttons'>
            <div>
            <button className='clear-cart' onClick={clearCart}>Clear Cart</button>
            <Link to={"/products"}><button className='continue-shopping'>Continue Shopping</button></Link>
            </div>
            <button onClick={()=>payTotal(cart)}
            className='pay-button'>Pay {formattedPrice(total)}</button>
          </div>
          </div>
          : <div ><div className='empty-cart'>Your cart is empty. 
            <Link to={`/products`} className='empty-cart-link'>Start shopping</Link>
          </div></div>
        }
      </div>
    : <div className='login-advice'>
        <div>Sign in <Link to={`/sign-in`}>
          <button className='login-advice-button'><FaArrowRightToBracket /></button>
          </Link> to access your cart
        </div>
      </div>}
      <Footer />
      </div>

  )
}

export default Cart