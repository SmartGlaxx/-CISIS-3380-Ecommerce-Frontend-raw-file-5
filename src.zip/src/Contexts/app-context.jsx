import React, {useEffect, useReducer, useState} from 'react'
import  reducer  from '../reducers/app-reducer'
import Axios from 'axios'
import API from '../resourses/api'

const LOADING = 'LOADING';
const ALERT='ALERT';  const SETSIDEBAR = 'SETSIDEBAR' ; 
const CURRENTUSERPARSED = 'CURRENTUSERPARSED' ; 
const SET_PRODUCTS = "SET_PRODUCTS"; const LOGGEDIN = "LOGGEDIN";
const SET_FILTERED_PRODUCTS = "SET_FILTERED_PRODUCTS"; const SET_ORDERS = "SET_ORDERS";
const SET_PRODUCT = "SET_PRODUCT"; const ADD_TO_CART = "ADD_TO_CART"
const PRODUCT_VIEW = "PRODUCT_VIEW"; const CHANGE_SORT = "CHANGE_SORT";
const SORT_PRODUCTS = "SORT_PRODUCTS"; const SET_FILTER_VALUES = "SET_FILTER_VALUES";
const CLEAR_FILTERS = "CLEAR_FILTERS"
const FILTER_PRODUCTS = "FILTER_PRODUCTS"; const SET_PRICES = "SET_PRICES"
const DECREASE_CART_QUNTITY = "DECREASE_CART_QUNTITY"; const INCREASE_CART_QUNTITY = "INCREASE_CART_QUNTITY";
const DELETE_CART_ITEM = "DELETE_CART_ITEM"; const CLEAR_CART = "CLEAR_CART";



const getLoggedIn = ()=>{
    let value
    if(localStorage.getItem('smartPacificLoggedIn') == "true"){
        value = localStorage.getItem('smartPacificLoggedIn')
    }else{
        value = localStorage.getItem('smartPacificLoggedIn')
    }
    return value
}


const getCurrentUser = ()=>{
    let value
    if(localStorage.getItem('smartPacificCurrentUser')){
         value = localStorage.getItem('smartPacificCurrentUser')
    }else{
        value = {}
    }
    return value
}

const getCart = ()=>{
    let value
    if(localStorage.getItem('smartPacificCart')){
         let initialValue = localStorage.getItem('smartPacificCart')
         value = JSON.parse(initialValue)
    }else{
        value = []
    }
    
    return value
}


const AppContext = React.createContext()
const initialState = {
    loggedIn : getLoggedIn(),
    currentUserParsed : {},
    currentUser : getCurrentUser(),
    alert : {status : false, msg : ''},
    loading : false,
    sidebarOpen : false,
    products: [],
    filteredProducts: [],
    product: {},
    featured: [],
    orders: [],
    view: "grid",
    cart: getCart(),
    sort: "price-lowest",
    filters: {
        search_text:"",
        category: "All",
        company: "All",
        color: "All",
        lowest_price: 0,
        highest_price: 0,
        price: 0,
        shipping: false
    }
}

export const AppProvider = ({children})=>{
    const [state, dispatch] = useReducer(reducer, initialState)
    
    const setAlert = (value)=>{
        dispatch({type: ALERT, payload: value})
    }

    const setLoading =(value)=> {
            dispatch({type : LOADING, payload : value})
     }


const fetchProducts = async()=>{
    dispatch({type: LOADING, payload: true})
    try{
        const productsData = await Axios.get(`${API}/products/all`)
        const {products} = productsData.data
        
        if(products){
            dispatch({type: SET_PRODUCTS, payload: products})
            dispatch({type: SET_FILTERED_PRODUCTS, payload: products})
            dispatch({type: LOADING, payload: false})
            let highest_price = Math.max(...products.map(product => product.price));
            dispatch({type: SET_PRICES, payload: highest_price})
        }else{
            dispatch({type: ALERT, payload: {status : true, msg : "Error fetching products"}})            
        }
    }catch(error){
        dispatch({type: ALERT, payload: {status : true, msg : "Error fetching products"}})
        dispatch({type: LOADING, payload: false})
    }
}


const fetchOrders = async()=>{
    const {_id} = state.currentUserParsed
    
    dispatch({type: LOADING, payload: true})
    try{
        const ordersData = await Axios.get(`${API}/orders/${_id}`)
        const {response, userOrders} = ordersData.data
        
        if(response == "Success"){
            dispatch({type: SET_ORDERS, payload: userOrders})
        }else{
            dispatch({type: ALERT, payload: {status : true, msg : "Error fetching orders"}})            
        }
    }catch(error){
        dispatch({type: ALERT, payload: {status : true, msg : "Error fetching orders"}})
        dispatch({type: LOADING, payload: false})
    }
}

useEffect(() => {
  fetchProducts()
  if(state.currentUserParsed){
      fetchOrders()
  }
}, [state.currentUserParsed]);


const fetchSingleProduct = async(id)=>{
    dispatch({type: LOADING, payload: true})
    try{
        const productsData = await Axios.get(`${API}/products/product/${id}`)
        const {product} = productsData.data
        
        if(product){
            dispatch({type: SET_PRODUCT, payload: product})
            dispatch({type: LOADING, payload: false})
        }else{
            dispatch({type: ALERT, payload: {status : true, msg : "Error fetching product"}})            
        }
    }catch(error){
        dispatch({type: ALERT, payload: {status : true, msg : "Error fetching product"}})
        dispatch({type: LOADING, payload: false})
    }
}

useEffect(() => {
  fetchProducts()
}, []);
   

   const setCurrentUser = (value)=>{
      
        localStorage.setItem('smartPacificCurrentUser',JSON.stringify(value))
    }

    const setCartToLocalStorage = (value)=>{
        localStorage.setItem('smartPacificCart',JSON.stringify(value))
    }

    const addItemToDBCart = async(cart)=>{
        try {
            
            const response = await Axios.patch(`${API}/cart`, { cart });
            console.log(response)
        } catch (error) {
            console.error('Error adding item to cart:', error);
        }
        
    }
    useEffect(()=>{
        setCartToLocalStorage(state.cart)
        addItemToDBCart(state.cart)
    },[state.cart])

   const fetchCurrentUser=async(userUrl)=>{

    const options = {
        url: userUrl,
        method : "GET",
        headers : {
            "Accept" : "application/json",
            "Content-Type" : "application/json;cjarset=UTF-8"
        }
    }
   
    const result = await Axios(options)
    const {response, user} = result.data
    
        if(response == "Success" && user){
            dispatch({type : CURRENTUSERPARSED , payload : user})
        }else{
            dispatch({type : CURRENTUSERPARSED , payload : {}})
        }
   }
   useEffect(()=>{
    const currentUserObj = state.currentUser     
    if(Object.keys(currentUserObj).length != 0){
        const {id} = JSON.parse(state.currentUser)
        if(id){
            fetchCurrentUser(`${API}/user/get-user/${id}`)
        }
    }
   },[state.currentUser])


   const setLoggedIn =(value)=>{
    
       if(value == true){
        localStorage.setItem('smartPacificLoggedIn',"true")
       }else if(value == false){
        localStorage.setItem('smartPacificLoggedIn',"false")
       }
   }

   const openSidebar = ()=>{
       dispatch({type : SETSIDEBAR, payload: !state.sidebarOpen})
   }

   const addToCart =(userId, id, productName, selectedColor, quantity, product)=>{
    dispatch({type:ADD_TO_CART, payload: {userId, id, productName, selectedColor, quantity, product}})
   }

   const setView = (value)=>{
    dispatch({type: PRODUCT_VIEW, payload: value})
   }

   const changeSort = (value)=>{
    dispatch({type: CHANGE_SORT, payload: value})
   }
   
   const setFilterValues =(e)=>{
    let {name, value} = e.target
    if(e.target.name == "category"){
        value = e.target.textContent
    }
    if(e.target.name == 'color'){
        value = e.target.dataset.color
    }
    if(name == "price"){
        value = Number(value)
    }
    if(name == "shipping"){
        value = e.target.checked
    }
    console.log(value)
    dispatch({type: SET_FILTER_VALUES, payload:{name,value}})
   }


   useEffect(()=>{
        dispatch({type: FILTER_PRODUCTS, payload: state.filters})
        dispatch({type: SORT_PRODUCTS, payload: state.sort})
   },[state.products, state.filters, state.sort])

   const clearFilterValues = ()=>{
    dispatch({type: CLEAR_FILTERS})
   }

   const decreaseCartItem = (cartItem)=>{
    dispatch({type: DECREASE_CART_QUNTITY, payload: cartItem})
        
   }

   const increaseCartItem = (cartItem)=>{
        dispatch({type: INCREASE_CART_QUNTITY, payload: cartItem})
   }
    
   const deleteCartItem =(id)=>{
        dispatch({type: DELETE_CART_ITEM, payload: id})
   }

   const clearCart = () =>{
        dispatch({type: CLEAR_CART})
   }

    return <AppContext.Provider value={{
        ...state, setCurrentUser, setLoggedIn, openSidebar, setAlert, fetchSingleProduct,
        addToCart, setView, changeSort, setFilterValues, clearFilterValues, decreaseCartItem, increaseCartItem,
        deleteCartItem, clearCart
    }}>
    {children}
    </AppContext.Provider>
}

export const UseAppContext = ()=>{
    return React.useContext(AppContext)
}

