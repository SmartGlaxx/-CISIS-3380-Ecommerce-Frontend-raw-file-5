// const API = 'http://pacific-backend1.onrender.com'
const API = 'http://localhost:5000'

export default API