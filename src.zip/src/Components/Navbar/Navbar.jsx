import React, {useState, useEffect} from 'react'
import "./Navbar.css"
import logo from "../../assets/images/shop-logo.png"
import { Link } from 'react-router-dom'
import { links } from '../../resourses/links'
import { UseAppContext } from '../../Contexts/app-context'
import { FaUser, FaBars, FaArrowRightFromBracket, FaArrowRightToBracket } from "react-icons/fa6"


const Navbar = () => {
    const {loggedIn, setLoggedIn, setCurrentUser, openSidebar, 
        currentUserParsed, cart} = UseAppContext()
    const [scrolling, setScrolling] = useState(false);
    const {_id, role} = currentUserParsed
   
    useEffect(() => {
        const handleScroll = () => {
        const isTop = window.scrollY < 10; 
        if (isTop !== scrolling) {
            setScrolling(isTop);
        }
        };

        window.addEventListener('scroll', handleScroll);

        return () => {
        window.removeEventListener('scroll', handleScroll);
        };
    }, [scrolling]);

    const navBarStyle = {
        position: "fixed", top:"0", width: "100%", left:"0", zIndex: "10",
        backgroundColor: scrolling ? 'transparent' : 'var(--background-color)', 
        transition: 'background-color 0.3s ease-in-out',
    };

    const setLoggedInAndNavigate = (value) =>{
        setLoggedIn(value)
        setCurrentUser({id:"",email:"",role:""})
        return window.location.href = '/sign-in'
    }
  
  return (
    <div className='nav-container' style={navBarStyle}>
        <Link to="/">
            <img src={logo} alt='logo' className='logo' />
        </Link>
        <ul className='nav-links-desktop'>
            {
                links.map(link =>{
                    const {id, name, url, icon, color} = link
                    return <li key={id} className='nav-link-desktop'>
                        <Link to={`${url}`} className='link'>
                            <span className='link-name' style={{display: "flex", marginTop:"1.2rem", alignItems:"center"}}>
                                <div style={{color:color, marginRight: "0.5rem",
                                marginTop:"0.1rem", fontSize: "var(--icon-size)"}}>{icon}
                                {/* {
                                    name == "Cart" ?  cart[0].userId == currentUserParsed._id ? <div className='cart-count'>{cart.length}</div> : 
                                    <div className='cart-count'>0</div> 
                                } */}
                                {/* {name === "Cart" ? 
                                (cart.length > 0 && cart[1].userId === currentUserParsed._id ? 
                                    <div className='cart-count'>{cart.length}</div> : 
                                    <div className='cart-count'>0</div>) 
                                : null} */}
                                {name === "Cart" ? 
                                (cart.length > 0 ? 
                                    <div className='cart-count'>{cart.filter(item => item.userId === currentUserParsed._id).length}</div> : 
                                    <div className='cart-count'>0</div>) 
                                : null}
                                </div ><span className={name=="Cart" && ``}>{name}</span>
                            </span>
                        </Link>
                    </li>
                })
            }
        </ul>
        
        <div className='right-buttons'>
        {
            loggedIn == "true" ? <>
            {role !== "admin" && <Link to={`/profile/${_id}`}><button className='profile-link-button'><FaUser className='icon'/></button></Link>}
            <button className='sign-out-button-desktop' onClick={()=>setLoggedInAndNavigate(false)}><FaArrowRightFromBracket /></button> 
            </>
            :
            <Link to={`/sign-in`} className='sign-in-link'><span >Sign in</span> <button className='sign-out-button-desktop'><FaArrowRightToBracket /></button></Link>
        }
        {
             role == "admin" && <Link to={`/admin`} className='admin-button-link'>
            <button className='admin-button-desktop'>
                Admin
            </button>    
            </Link> 
        }
            <button onClick={openSidebar} className='mobile-nav-button'><FaBars className='menu-button' /></button>
        </div>
    </div>
  )
}

export default Navbar