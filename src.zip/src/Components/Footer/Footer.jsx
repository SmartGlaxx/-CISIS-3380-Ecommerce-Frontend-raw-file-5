import React from 'react'
import "./footer.css"

const Footer = () => {
  return (
    <div className='footer'>
         <div className="footer-column">
        <h5>Smart Pacific Ecommerce</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac justo quis mi dignissim bibendum.</p>
        </div>
        <div className="footer-column">
          <h6>Store Locations</h6>
          <div className='footer-ul'>
            <div className='footer-li'>Vancouver</div>
            <div className='footer-li'>Surrey</div>
            <div className='footer-li'>Tsawwassen</div>
            <div className='footer-li'>Langley</div>
          </div>
        </div>
        <div className="footer-column">
          <h6>Copyright {new Date().getFullYear()}</h6>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac justo quis mi dignissim bibendum.</p>
        </div>
    </div>
  )
}

export default Footer
