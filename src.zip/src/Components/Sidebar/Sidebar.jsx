import React from 'react'
import { links } from '../../resourses/links'
import { Link } from 'react-router-dom'
import { UseAppContext } from '../../Contexts/app-context'
import "./Sidebar.css"
import { Button } from '@mui/material'


const Sidebar = () => {
  const {sidebarOpen, openSidebar, loggedIn, setLoggedIn, setCurrentUser, cart} = UseAppContext()
  
  const setLoggedInAndNavigate = (value) =>{
      setLoggedIn(value)
      setCurrentUser({id:"",email:"",role:""})
      return window.location.href = '/sign-in'
  }
  return (
    <div className={sidebarOpen ? "sidebar-open" : "sidebar-closed"}>
      <ul className='nav-links-mobile'>
        {
          links.map(link =>{
            const {id, name, url, icon} = link
            return <li key={id} className='nav-link-mobile'>
              <Link to={`${url}`} className='link' onClick={openSidebar}>
                <span className='sidebar-link-name'>
                {name}&nbsp;{icon}
                {
                    name == "Cart" && <div className='cart-count'>{cart.length}</div>
                }
               </span>
                </Link>
            </li>
          })
        }
        </ul>
        <hr />
        {
          
          loggedIn == "true" && <Button className='sign-out-button-mobile' onClick={()=>setLoggedInAndNavigate(false)}>Sign out</Button>
        }
    </div>
  )
}

export default Sidebar