import React from 'react'
import { UseAppContext } from '../../Contexts/app-context'
import GridView from '../ProductViews/GridView'
import ListView from '../ProductViews/ListView'

const ProductList = ({products}) => {
  const {view} = UseAppContext()
  return (
    <>
        {view == "grid" ? <GridView /> : <ListView />}
    </>
  )
}

export default ProductList